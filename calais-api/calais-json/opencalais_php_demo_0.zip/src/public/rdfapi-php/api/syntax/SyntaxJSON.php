<?php
// Include Syntax classes
// $Id: SyntaxJSON.php 552 2007-11-23 09:12:11Z p_frischmuth $
require_once( RDFAPI_INCLUDE_DIR . 'syntax/JsonParser.php' );
require_once( RDFAPI_INCLUDE_DIR . 'syntax/JsonSerializer.php' );
?>