<?php
/**
 * Created by JetBrains PhpStorm.
 * User: johannes
 * Date: 5/3/14
 * Time: 2:10 PM
 * To change this template use File | Settings | File Templates.
 */

echo "<h1>Memebers Area Only</h1>";
echo anchor('login/logout', 'Login Out');