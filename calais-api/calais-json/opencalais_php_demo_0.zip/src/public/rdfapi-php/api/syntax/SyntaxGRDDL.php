<?php
// ----------------------------------------------------------------------------------
// Syntax RDF
// ----------------------------------------------------------------------------------
//
// Description               : Syntax RDF package
//
//
// Author: Tobias Gau�	<tobias.gauss@web.de>
//
// ----------------------------------------------------------------------------------


// Include Syntax classes
require_once( RDFAPI_INCLUDE_DIR . 'syntax/GRDDLParser.php' );
?>