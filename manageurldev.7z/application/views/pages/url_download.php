<?php
/**
 * Created by JetBrains PhpStorm.
 * User: johannes
 * Date: 5/7/14
 * Time: 10:31 AM
 * To change this template use File | Settings | File Templates.
 */
?>
<h2>URL Download</h2>
<div id="table-wrapper-download">
    <div id="table-scroll-download ">
        <table id="url_download_table"  border="0">
            <thead>
            <tr>
                <th class="url_download_table_first"><span class="text">Date</span></th>
                <th class="url_download_table_second"><span class="text">Name</span></th>
                <th class="url_download_table_third"><span class="text">Download</span></th>
                <th class="url_download_table_fourth"><span class="text">Description</span></th>
                <th class="url_download_table_fourth"><span class="text">Description 2</span></th>
            </tr>
            </thead>
            <tbody>
            <tr> <td>25.04.2014</td> <td>Car URL's March 2014</td> <td><button>Download</button></td> <td>3, 0</td> <td>3, 1</td>  </tr>
            <tr> <td>1, 1</td> <td>2, 1</td> <td>3, 1</td> <td>3, 1</td> <td>3, 1</td> </tr>
            <tr> <td>2, 1</td> <td></td> <td></td> <td></td> <td></td>  </tr>
            <tr> <td>2, 1</td> <td></td> <td></td> <td></td> <td></td>  </tr>
            <tr> <td>2, 1</td> <td></td> <td></td> <td></td> <td></td>  </tr>
            <tr> <td>2, 1</td> <td></td> <td></td> <td></td> <td></td>  </tr>
            <tr> <td>2, 1</td> <td></td> <td></td> <td></td> <td></td>  </tr>
            <tr> <td>2, 1</td> <td></td> <td></td> <td></td> <td></td> </tr>
            <tr> <td>2, 1</td> <td></td> <td></td> <td></td> <td></td>  </tr>
            </tbody>
        </table>
    </div>
</div><!--#table-wrapper-download-->
