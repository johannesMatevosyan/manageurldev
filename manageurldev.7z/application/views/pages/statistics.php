<?php
/**
 * Created by JetBrains PhpStorm.
 * User: johannes
 * Date: 5/8/14
 * Time: 3:46 PM
 * To change this template use File | Settings | File Templates.
 */
?>
<h2>Statistics</h2>
<br>
<b>Logs</b><button id="domains">Total Unique Domains 156.000</button><b>URL Database Stats</b>
<br>
<br>
<table align="center" width="98%" border="1" >
    <tr>
        <th align="left">
            <button>Clear Logs</button>
            <button>Copy Logs</button>
            <button>Save Logs</button>
        </th>
        <th>
            Select data:
            <select>
                <option value="volvo">Contnt Analysis</option>
                <option value="saab">Saab</option>
                <option value="mercedes">Mercedes</option>
                <option value="audi">Audi</option>
            </select>
        </th>
    </tr>
    <tr>
        <th width="50%">
        <!-- <div id="time_indication">
                <tr><td>2600 news domains added</td></tr>
                <tr><td>....................................</td></tr>
                <tr><td>2600 news domains added</td></tr>
                <tr><td>....................................</td></tr>
                <tr><td>2600 news domains added</td></tr>
                <tr><td>....................................</td></tr>
                <tr><td>2600 news domains added</td></tr>
                <tr><td>....................................</td></tr>
                <tr><td>2600 news domains added</td></tr>
                <tr><td>....................................</td></tr>
            </div>-->

            <div id="time_indication">
                <p>2600 news domains added - 4:44 PM 30.04.2014<br>
                ----------------------------------------------------</p>
                <p>1500 news domains added - 4:44 PM 30.04.2014<br>
                   2600 news domains added - 4:44 PM 30.04.2014<br>
        ----------------------------------------------------------------------------</p>
                2600 news domains added<br>
                ....................................<br>
                2600 news domains added<br>
                ....................................<br>
                2600 news domains added<br>
                ....................................<br>
                2600 news domains added<br>
            </div>
        </th>
        <th>
            <table id="child_table" border="1" width="100%">
                <tr>
                    <th>data point</th>
                    <th>value</th>
                </tr>
                <tr>
                    <td>Cars</td>
                    <td>2164</td>
                </tr>
                <tr>
                    <td>Health</td>
                    <td>4000</td>
                </tr>
                <tr>
                    <td>Music</td>
                    <td>200</td>
                </tr>
                <tr>
                    <td>Science</td>
                    <td>33</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td></td>
                </tr>
            </table>

        </th>
    </tr>
</table>
