<?php
// ----------------------------------------------------------------------------------
// DBase
// ----------------------------------------------------------------------------------
//
// Description               : DBase package
//
//
// Author: Tobias Gau�	<tobias.gauss@web.de>
//
// ----------------------------------------------------------------------------------

// Include DBase class
require_once( RDFAPI_INCLUDE_DIR . 'model/DbModel.php' );
// include adodb classes
require_once(RDFAPI_INCLUDE_DIR .'util/adodb/adodb.inc.php');
?>