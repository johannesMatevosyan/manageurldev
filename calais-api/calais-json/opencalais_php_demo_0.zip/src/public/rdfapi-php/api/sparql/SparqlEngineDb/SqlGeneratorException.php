<?php
/**
*   Exception when generating the SQL statement
*
*   @author Christian Weiske <cweiske@cweiske.de>
*   @license http://www.gnu.org/licenses/lgpl.html LGPL
*
*   @package sparql
*/
class SparqlEngineDb_SqlGeneratorException extends Exception
{
}

?>