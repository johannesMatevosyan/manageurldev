<?php

$calais_API_key = "your-api-key-goes-here";

?>