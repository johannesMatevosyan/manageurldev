<h1>Congrats!</h1>
<p>
    Your account has been created. <?php echo anchor('login', 'Login Now'); ?>
</p>