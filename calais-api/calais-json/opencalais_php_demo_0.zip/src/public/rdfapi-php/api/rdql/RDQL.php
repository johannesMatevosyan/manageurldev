<?php
// ----------------------------------------------------------------------------------
// RDQL
// ----------------------------------------------------------------------------------
//
// Description               : Rdql package
// ----------------------------------------------------------------------------------


// include RDQL classes
require_once( RDFAPI_INCLUDE_DIR . 'rdql/RdqlParser.php' );
require_once( RDFAPI_INCLUDE_DIR . 'rdql/RdqlEngine.php' );
require_once( RDFAPI_INCLUDE_DIR . 'rdql/RdqlDbEngine.php' );
require_once( RDFAPI_INCLUDE_DIR . 'rdql/RdqlMemEngine.php' );
require_once( RDFAPI_INCLUDE_DIR . 'rdql/RdqlResultIterator.php' );

?>