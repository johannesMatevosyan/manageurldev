<?php
/**
*   A prepared statement that can be execute()d later multiple
*   times with different variable values.
*
*   @license http://www.gnu.org/licenses/lgpl.html LGPL
*   @package sparql
*/
class SparqlEngine_PreparedStatement
{
    public function execute($arVariables, $resultform)
    {
        //FIXME
    }

}
?>